# Placeholder testimonial images
# These would be replaced with actual photos of veterinary professionals

# For now, using placeholder service that generates professional avatars
# testimonial1.jpg - Dr. Sarah Johnson
# testimonial2.jpg - Dr. Michael Chen  
# testimonial3.jpg - Lisa Rodriguez

# In production, these would be actual photos with proper permissions
